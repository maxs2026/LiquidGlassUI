package com.example.liquidglassui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = 0xFF080D18, WHITE = 0xFFF7FAFF, MUTED = 0xFF9EADC4;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable shape(int top, int bottom, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{top, bottom});
        d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void space(LinearLayout parent, int h) {
        View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private TextView pill(String label) {
        TextView t = text(label, 11, 0xFFDCEAFF, true); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(13), dp(8), dp(13), dp(8));
        t.setBackground(shape(0xCC314B70, 0xAA1C2A40, 0x77A9C8F5, 30)); return t;
    }
    private void section(LinearLayout root, String name, String hint) {
        TextView h = text(name, 17, WHITE, true); root.addView(h);
        if (hint != null) { TextView s = text(hint, 12, MUTED, false); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(3); root.addView(s,p); }
        space(root, 11);
    }
    private LinearLayout card(LinearLayout parent, int top, int bottom) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(17),dp(16),dp(17),dp(16));
        c.setBackground(shape(top,bottom,0x55FFFFFF,24));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(11); parent.addView(c,p); return c;
    }
    private Button actionButton(String label, boolean primary, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(14); b.setAllCaps(false); b.setTextColor(WHITE);
        b.setBackground(shape(primary?0xFF6D9FE8:0x663B4D67, primary?0xFF315A91:0x44202D41, 0x66FFFFFF, 17));
        b.setPadding(dp(8),dp(7),dp(8),dp(7)); b.setMinHeight(dp(50)); b.setElevation(dp(2));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Allow Display over other apps, then tap Activate again.",Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))); return;
        }
        startService(new Intent(this,GlassOverlayService.class));
        Toast.makeText(this,"Liquid Glass is active. Tap the floating GLASS tab.",Toast.LENGTH_LONG).show();
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.TRANSPARENT); getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(21),dp(58),dp(21),dp(28));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF17243A,0xFF0B1220,0xFF070B13}));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("✦  LIQUID GLASS  /  ANDROID",10,0xFFADC9F4,true); brand.setLetterSpacing(.13f);
        top.addView(brand,new LinearLayout.LayoutParams(0,-2,1)); top.addView(pill("V 0.3  •  BETA")); root.addView(top);
        space(root,17);
        TextView title=text("Your phone,\nwith a little more magic.",31,WHITE,true); title.setLineSpacing(dp(1),1f); root.addView(title);
        space(root,8); root.addView(text("A refined glass-inspired Control Center.",14,0xFFB8C7DC,false));
        space(root,22);

        LinearLayout hero=card(root,0xEE344D70,0xDD17253A);
        LinearLayout heroTop=new LinearLayout(this); heroTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView heroTitle=text("Control Center",20,WHITE,true); heroTop.addView(heroTitle,new LinearLayout.LayoutParams(0,-2,1));
        heroTop.addView(pill("● READY")); hero.addView(heroTop);
        space(hero,7); hero.addView(text("Your glass experience is ready to launch.",13,0xFFE0E9F7,false));
        space(hero,15);
        LinearLayout preview=new LinearLayout(this); preview.setOrientation(LinearLayout.VERTICAL); preview.setPadding(dp(12),dp(12),dp(12),dp(12));
        preview.setBackground(shape(0xBB101A2A,0xAA17253A,0x66FFFFFF,19));
        TextView previewTitle=text("CONTROL CENTER  ·  PREVIEW",9,0xFFAFC9F1,true); preview.addView(previewTitle);
        space(preview,9);
        LinearLayout tiles=new LinearLayout(this); tiles.setGravity(Gravity.CENTER_VERTICAL);
        String[] names={"◉  Wi-Fi","ᛒ  Bluetooth","▣  Network","✈  Airplane"};
        for(String n:names){ TextView tile=text(n,10,WHITE,true); tile.setGravity(Gravity.CENTER); tile.setPadding(dp(5),dp(12),dp(5),dp(12)); tile.setBackground(shape(0xBB49688E,0x88304462,0x55FFFFFF,13)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(dp(2),0,dp(2),0); tiles.addView(tile,p); }
        preview.addView(tiles); space(preview,9);
        TextView slider1=text("☼  Brightness     ━━━━━━━━━━━━━●",11,0xFFE4EDFA,true); preview.addView(slider1);
        space(preview,6); preview.addView(text("♫  Media volume  ━━━━━━━━━●",11,0xFFE4EDFA,true)); hero.addView(preview);

        space(root,10); section(root,"Get started","Two permissions unlock the floating glass panel.");
        LinearLayout perm=card(root,0xAA25364F,0x88202C40);
        TextView p1=text("01   Display over other apps",14,WHITE,true); perm.addView(p1);
        space(perm,3); perm.addView(text("Allows the floating GLASS shortcut to appear above apps.",11,MUTED,false));
        space(perm,10); perm.addView(actionButton("Grant overlay permission",false,()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())))));
        space(perm,9); TextView p2=text("02   Modify system settings",14,WHITE,true); perm.addView(p2);
        space(perm,3); perm.addView(text("Needed for the brightness slider to control screen brightness.",11,MUTED,false));
        space(perm,10); perm.addView(actionButton("Grant system settings permission",false,()->startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName())))));

        section(root,"Make it happen","Turn on your floating Control Center.");
        root.addView(actionButton("✦   Activate Liquid Glass",true,this::startOverlay));
        space(root,8); root.addView(actionButton("Turn off floating panel",false,()->{stopService(new Intent(this,GlassOverlayService.class));Toast.makeText(this,"Floating panel stopped.",Toast.LENGTH_SHORT).show();}));

        space(root,20); section(root,"Included in this release",null);
        LinearLayout features=card(root,0x772A3B54,0x55202C40);
        features.addView(text("✦  Floating glass shortcut\n\n◉  Wi-Fi, Bluetooth & network shortcuts\n\n☼  Brightness control\n\n♫  Media volume control\n\n✧  Draggable on-screen handle",13,0xFFD8E3F2,false));
        space(root,8);
        TextView note=text("Designed for Android. Some network controls open your device's Settings because Android restricts direct changes. LiquidGlassUI uses its own overlay and does not replace the protected system notification shade or status bar.",11,0xFF8494AA,false);
        note.setLineSpacing(dp(3),1f); root.addView(note);
        setContentView(scroll);
    }
}
