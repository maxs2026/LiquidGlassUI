# LiquidGlassUI — Phase 2 (v0.3)

An Android Control Center overlay with a premium dark glass-inspired interface.

## What's new in v0.3
- Redesigned main app dashboard with a consistent dark glass visual system.
- Added a visual Control Center preview and clearer permission/setup cards.
- Improved overlay contrast so content behind the panel is much less distracting.
- Refined tile and slider surfaces while keeping the floating draggable GLASS handle.

## Build
Open this project in Android Studio or run the included GitHub Actions workflow. The workflow builds `:app:assembleDebug` and uploads `LiquidGlassUI-debug-apk`.

## Android limitations
The app draws its own overlay. It does not replace Android's protected notification shade or status bar. Wi-Fi, Bluetooth, mobile network, and airplane shortcuts open the relevant Android Settings pages where direct system changes are restricted. Brightness control requires Modify System Settings permission.
