package com.example.liquidglassui;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GlassOverlayService extends Service {
    WindowManager wm; View handle, panel; boolean open = false;
    int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
    @Override public void onCreate() {
        super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        handle = new View(this);
        WindowManager.LayoutParams hp = new WindowManager.LayoutParams(dp(104), dp(64),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        hp.gravity = Gravity.TOP | Gravity.RIGHT;
        wm.addView(handle, hp);
        handle.setOnTouchListener(new View.OnTouchListener() {
            float startY;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction()==MotionEvent.ACTION_DOWN) { startY=e.getRawY(); return true; }
                if (e.getAction()==MotionEvent.ACTION_UP) {
                    if (e.getRawY()-startY > dp(18)) showPanel();
                    return true;
                }
                return true;
            }
        });
    }
    GradientDrawable glass(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(26));
        d.setStroke(dp(1), 0x55FFFFFF); return d;
    }
    TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); return t;
    }
    LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    void addSlider(LinearLayout parent, String name, int max, int value, SeekBar.OnSeekBarChangeListener listener) {
        LinearLayout block=vertical(); block.setPadding(dp(12),dp(7),dp(12),dp(5)); block.setBackground(glass(0x553D485B));
        TextView title=label(name,14); title.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); block.addView(title);
        SeekBar seek=new SeekBar(this); seek.setMax(max); seek.setProgress(Math.max(0,Math.min(max,value))); seek.setOnSeekBarChangeListener(listener);
        block.addView(seek);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(76)); p.setMargins(0,dp(7),0,dp(2)); parent.addView(block,p);
    }
    void addTile(LinearLayout row, String title, String action, int weight) {
        TextView tile=label(title,13); tile.setBackground(glass(0x664C5B70));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(72),weight); p.setMargins(dp(4),dp(4),dp(4),dp(4)); row.addView(tile,p);
        tile.setOnClickListener(v -> launch(action));
    }
    void showPanel() {
        if(open) return;
        LinearLayout box=vertical(); box.setPadding(dp(16),dp(16),dp(16),dp(18)); box.setBackground(glass(0xEF202938));
        String now=new SimpleDateFormat("EEEE, MMM d  •  h:mm a", Locale.getDefault()).format(new Date());
        TextView top=label("Control Center",20); top.setTypeface(null,1); top.setGravity(Gravity.START); box.addView(top);
        TextView date=label(now,12); date.setTextColor(0xFFCFD7E5); date.setGravity(Gravity.START); box.addView(date);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
        addTile(row,"◉  Wi-Fi","wifi",1); addTile(row,"ᛒ  Bluetooth","bluetooth",1);
        box.addView(row);
        LinearLayout row2=new LinearLayout(this); row2.setGravity(Gravity.CENTER);
        addTile(row2,"▣  Network","network",1); addTile(row2,"✈  Airplane","airplane",1);
        box.addView(row2);
        addSlider(box,"☼   Brightness",255,currentBrightness(),new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int value,boolean user) {
                if(user && Settings.System.canWrite(GlassOverlayService.this)) {
                    try { Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE,Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                        Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,value); } catch(Exception ignored) {}
                }
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), vol=audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        addSlider(box,"♫   Media volume",max,vol,new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int value,boolean user) { if(user) audio.setStreamVolume(AudioManager.STREAM_MUSIC,value,0); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        TextView close=label("⌃   Close",13); close.setPadding(0,dp(10),0,0); box.addView(close); close.setOnClickListener(v -> hidePanel());
        panel=box;
        WindowManager.LayoutParams pp=new WindowManager.LayoutParams(-1,dp(470),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        pp.gravity=Gravity.TOP; pp.y=dp(20); wm.addView(panel,pp); open=true;
    }
    int currentBrightness() {
        try { return Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,128); }
        catch(Exception e) { return 128; }
    }
    void launch(String which) {
        String action=Settings.ACTION_SETTINGS;
        if(which.equals("wifi")) action=Settings.ACTION_WIFI_SETTINGS;
        else if(which.equals("bluetooth")) action=Settings.ACTION_BLUETOOTH_SETTINGS;
        else if(which.equals("network")) action=Settings.ACTION_WIRELESS_SETTINGS;
        else if(which.equals("airplane")) action=Settings.ACTION_AIRPLANE_MODE_SETTINGS;
        try { Intent i=new Intent(action); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch(Exception ignored) {}
    }
    void hidePanel() { if(panel!=null) { try { wm.removeView(panel); } catch(Exception ignored) {} panel=null; } open=false; }
    @Override public void onDestroy() { hidePanel(); if(handle!=null) try { wm.removeView(handle); } catch(Exception ignored) {} super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
