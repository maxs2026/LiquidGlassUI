package com.example.liquidglassui;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GlassOverlayService extends Service {
    private WindowManager wm;
    private TextView handle;
    private View panel;
    private WindowManager.LayoutParams handleParams;
    private boolean open = false;
    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Display-over-apps permission is required.", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        addHandle();
        Toast.makeText(this, "Liquid Glass is active. Tap the glass pill to open.", Toast.LENGTH_LONG).show();
    }

    private GradientDrawable glass(int top, int bottom, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{top, bottom});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private void addHandle() {
        handle = new TextView(this);
        handle.setText("✦  GLASS");
        handle.setTextColor(Color.WHITE);
        handle.setTextSize(11);
        handle.setTypeface(null, 1);
        handle.setGravity(Gravity.CENTER);
        handle.setElevation(dp(12));
        handle.setBackground(glass(0xF06D8EBB, 0xE52A3B56, 0xAAFFFFFF, 24));

        handleParams = new WindowManager.LayoutParams(dp(86), dp(42),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        handleParams.gravity = Gravity.TOP | Gravity.RIGHT;
        handleParams.x = dp(8);
        handleParams.y = (int)(getResources().getDisplayMetrics().heightPixels * .32f);

        wm.addView(handle, handleParams);
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int originX, originY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        originX = handleParams.x; originY = handleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            int maxX = Math.max(0, getResources().getDisplayMetrics().widthPixels - dp(86));
                            int maxY = Math.max(0, getResources().getDisplayMetrics().heightPixels - dp(42));
                            handleParams.x = Math.max(0, Math.min(maxX, originX - (int)dx));
                            handleParams.y = Math.max(dp(28), Math.min(maxY, originY + (int)dy));
                            try { wm.updateViewLayout(handle, handleParams); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) showPanel();
                        return true;
                }
                return true;
            }
        });
    }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addTile(LinearLayout row, String title, String subtitle, String action, boolean accent) {
        LinearLayout tile = vertical();
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(13), dp(11), dp(10), dp(10));
        tile.setBackground(glass(
            accent ? 0xDD5279B2 : 0xAA536176,
            accent ? 0xBB29446B : 0x88303C50,
            0x55FFFFFF, 20));
        TextView name = label(title, 14, Color.WHITE);
        name.setTypeface(null, 1);
        name.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        tile.addView(name);
        TextView hint = label(subtitle, 10, 0xFFD5E0F0);
        hint.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        hint.setPadding(0, dp(4), 0, 0);
        tile.addView(hint);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(82), 1);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        row.addView(tile, p);
        tile.setOnClickListener(v -> launch(action));
    }

    private void addSlider(LinearLayout parent, String name, int max, int value,
                           SeekBar.OnSeekBarChangeListener listener) {
        LinearLayout block = vertical();
        block.setPadding(dp(13), dp(9), dp(13), dp(7));
        block.setBackground(glass(0xAA64748A, 0x66404D62, 0x44FFFFFF, 18));
        TextView title = label(name, 13, Color.WHITE);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        block.addView(title);
        SeekBar seek = new SeekBar(this);
        seek.setMax(Math.max(1, max));
        seek.setProgress(Math.max(0, Math.min(Math.max(1, max), value)));
        seek.setOnSeekBarChangeListener(listener);
        block.addView(seek);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(4), dp(5), dp(4), dp(5));
        parent.addView(block, p);
    }

    private void showPanel() {
        if (open || wm == null) return;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout box = vertical();
        box.setPadding(dp(16), dp(16), dp(16), dp(18));
        box.setBackground(glass(0xF02D3B52, 0xF0141D2B, 0x99FFFFFF, 30));
        box.setElevation(dp(18));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("Control Center", 21, Color.WHITE);
        title.setTypeface(null, 1);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        heading.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = label("✕", 18, Color.WHITE);
        close.setBackground(glass(0x665D6C82, 0x44333E50, 0x66FFFFFF, 30));
        close.setPadding(dp(12), dp(5), dp(12), dp(5));
        heading.addView(close);
        close.setOnClickListener(v -> hidePanel());
        box.addView(heading);

        String now = new SimpleDateFormat("EEEE, MMM d  •  h:mm a", Locale.getDefault()).format(new Date());
        TextView date = label(now, 12, 0xFFD0DCEC);
        date.setGravity(Gravity.START);
        date.setPadding(0, dp(3), 0, dp(9));
        box.addView(date);

        LinearLayout row1 = new LinearLayout(this);
        addTile(row1, "◉  Wi-Fi", "Open network settings", "wifi", true);
        addTile(row1, "ᛒ  Bluetooth", "Connect devices", "bluetooth", false);
        box.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        addTile(row2, "▣  Mobile network", "SIM and data settings", "network", false);
        addTile(row2, "✈  Airplane mode", "Wireless settings", "airplane", false);
        box.addView(row2);

        addSlider(box, "☼   Brightness", 255, currentBrightness(),
            new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar s, int value, boolean user) {
                    if (user && Settings.System.canWrite(GlassOverlayService.this)) {
                        try {
                            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, value);
                        } catch (Exception ignored) {}
                    }
                }
                public void onStartTrackingTouch(SeekBar s) {}
                public void onStopTrackingTouch(SeekBar s) {}
            });

        AudioManager audio = (AudioManager)getSystemService(AUDIO_SERVICE);
        int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        addSlider(box, "♫   Media volume", max, vol, new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int value, boolean user) {
                if (user) audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        TextView footer = label("Liquid Glass  •  Tap ✕ to close", 10, 0xFFB8C7DC);
        footer.setPadding(0, dp(10), 0, 0);
        box.addView(footer);
        scroll.addView(box);
        panel = scroll;

        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(-1,
            Math.min(getResources().getDisplayMetrics().heightPixels - dp(48), dp(590)),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        pp.y = dp(22);
        wm.addView(panel, pp);
        panel.startAnimation(new AlphaAnimation(0f, 1f) {{ setDuration(180); }});
        open = true;
    }

    private int currentBrightness() {
        try { return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128); }
        catch (Exception e) { return 128; }
    }

    private void launch(String which) {
        String action = Settings.ACTION_SETTINGS;
        if (which.equals("wifi")) action = Settings.ACTION_WIFI_SETTINGS;
        else if (which.equals("bluetooth")) action = Settings.ACTION_BLUETOOTH_SETTINGS;
        else if (which.equals("network")) action = Settings.ACTION_WIRELESS_SETTINGS;
        else if (which.equals("airplane")) action = Settings.ACTION_AIRPLANE_MODE_SETTINGS;
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "This setting is not available on this device.", Toast.LENGTH_SHORT).show();
        }
    }

    private void hidePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        open = false;
    }

    @Override public void onDestroy() {
        hidePanel();
        if (handle != null && wm != null) {
            try { wm.removeView(handle); } catch (Exception ignored) {}
            handle = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
