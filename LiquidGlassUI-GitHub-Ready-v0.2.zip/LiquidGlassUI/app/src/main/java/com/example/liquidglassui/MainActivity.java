package com.example.liquidglassui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{color, 0xCC25364B});
        d.setCornerRadius(dp(24));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please allow Display over other apps, then tap Enable again.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
            return;
        }
        startService(new Intent(this, GlassOverlayService.class));
        Toast.makeText(this, "Liquid Glass handle is starting. Look along the right edge.", Toast.LENGTH_LONG).show();
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(0xFF080D16);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(58), dp(22), dp(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xFF101A2B, 0xFF080B13}));

        TextView eyebrow = text("LIQUID GLASS • ANDROID", 11, 0xFF9DBBEB);
        eyebrow.setLetterSpacing(.14f);
        root.addView(eyebrow);

        TextView title = text("Liquid Glass UI", 32, Color.WHITE);
        title.setTypeface(null, 1);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(8); root.addView(title, tp);

        TextView sub = text("A fresh Control Center, inspired by iOS.", 14, 0xFFB8C5D8);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(5); root.addView(sub, sp);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(bg(0xAA344D70, 0x66FFFFFF));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(24); root.addView(hero, hp);
        TextView heroTitle = text("Your glass panel is ready", 18, Color.WHITE);
        heroTitle.setTypeface(null, 1); hero.addView(heroTitle);
        TextView heroInfo = text("Enable the overlay, then tap the small glowing pill on the right edge of your screen. Drag it anywhere you like.", 13, 0xFFE0E8F4);
        heroInfo.setPadding(0, dp(8), 0, 0); hero.addView(heroInfo);

        root.addView(button("1. Grant display-over-apps permission", () -> {
            if (!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            else Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show();
        }));
        root.addView(button("2. Grant modify-system-settings permission", () -> {
            if (!Settings.System.canWrite(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            else Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show();
        }));
        root.addView(button("Enable Liquid Glass overlay", this::startOverlay));
        root.addView(button("Disable overlay", () -> {
            stopService(new Intent(this, GlassOverlayService.class));
            Toast.makeText(this, "Liquid Glass overlay stopped.", Toast.LENGTH_SHORT).show();
        }));

        TextView note = text("CONTROL CENTER FEATURES\nWi-Fi • Bluetooth • Network • Airplane mode\nBrightness and media-volume sliders\n\nNetwork shortcuts open Android settings where system restrictions apply. This app draws its own overlay; it does not replace Android's protected notification shade or status bar.", 12, 0xFF9EADC2);
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);
        setContentView(root);
    }
}
