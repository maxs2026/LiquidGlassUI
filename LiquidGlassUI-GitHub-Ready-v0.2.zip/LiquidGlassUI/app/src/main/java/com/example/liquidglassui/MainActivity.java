package com.example.liquidglassui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(v -> action.run()); return b;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24), dp(58), dp(24), dp(24));
        root.setBackgroundColor(0xFF10131B);
        TextView title = new TextView(this); title.setText("Liquid Glass UI"); title.setTextColor(-1); title.setTextSize(30); title.setTypeface(null, 1);
        TextView sub = new TextView(this); sub.setText("Liquid Glass control center • Android 14"); sub.setTextColor(0xFFB8C0D0); sub.setTextSize(14);
        root.addView(title); root.addView(sub);
        root.addView(button("1. Grant display-over-apps permission", () -> {
            if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }));
        root.addView(button("2. Grant modify-system-settings permission", () -> {
            if (!Settings.System.canWrite(this)) startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
        }));
        root.addView(button("Enable Liquid Glass overlay", () -> {
            if (Settings.canDrawOverlays(this)) startService(new Intent(this, GlassOverlayService.class));
            else startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }));
        root.addView(button("Disable overlay", () -> stopService(new Intent(this, GlassOverlayService.class))));
        TextView note = new TextView(this);
        note.setText("\nHow to use\n• Swipe down from the top-right corner to open Control Center.\n• Brightness and media volume sliders are interactive.\n• Network tiles open the corresponding Android settings.\n\nThis is an early prototype. Android controls its real status bar and notification shade, so the overlay cannot fully replace them.");
        note.setTextColor(0xFF9AA5B5); note.setTextSize(13); note.setPadding(0, dp(12), 0, 0); root.addView(note);
        setContentView(root);
    }
}
