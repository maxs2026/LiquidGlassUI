# LiquidGlassUI 0.2

Android 14-friendly Liquid Glass-inspired Control Center overlay.

## What's new in 0.2
- Visible floating glass handle on the right edge.
- Tap the handle to open the custom Control Center.
- Drag the handle to reposition it.
- Redesigned translucent glass panel and rounded control tiles.
- Brightness and media-volume sliders.
- Wi-Fi, Bluetooth, mobile network, and airplane-mode shortcuts open Android settings where direct system control is restricted.
- Clear activation and permission feedback.

## Build
The existing GitHub Actions workflow (`.github/workflows/build-apk.yml`) builds the debug APK and uploads it as an artifact.

## Important Android limitations
This app uses Android's Display over other apps permission to draw its own overlay. It does not replace the protected Android notification shade or system status bar. Some wireless controls open Android Settings because Android restricts third-party apps from changing those settings directly.
