# LiquidGlassUI — Android prototype v0.2

A Java Android Studio project for an iOS-inspired translucent Control Center overlay. It is an early prototype, not a replacement for Android's protected system status bar or notification shade.

## Build automatically with GitHub Actions (phone-only)

This repository includes `.github/workflows/build-apk.yml`. It uses GitHub-hosted Ubuntu, Java 17, Android SDK 35, and Gradle 8.7. No computer, AndroidIDE, AIDE, or local Gradle installation is needed.

1. Upload **all files and folders inside this project folder** to the root of your GitHub repository (the files should include `app/`, `build.gradle`, `settings.gradle`, and `.github/`). Do not upload only the ZIP as a single file.
2. Commit the upload to the `main` branch.
3. Open the repository's **Actions** tab and select **Build LiquidGlassUI APK**.
4. Open the newest completed run. A green check means the workflow completed successfully.
5. Under **Artifacts**, download `LiquidGlassUI-debug-apk`. Extract the ZIP to obtain `app-debug.apk`.

The workflow also supports manual runs from Actions → Build LiquidGlassUI APK → Run workflow.

## Install and initial setup

1. Install `app-debug.apk` on the Android device. Android may ask you to allow installation from the browser or file manager you used; only proceed if this APK came from your own GitHub Actions run.
2. Open **Liquid Glass UI**.
3. Grant **Display over other apps**.
4. Grant **Modify system settings** if you want the brightness slider to work.
5. Tap **Enable Liquid Glass overlay**.
6. Try swiping down inside the small top-right trigger area. If the phone's own edge gestures conflict, disable the overlay from the app and report what happened.

## Prototype features

- Small top-right overlay gesture trigger.
- Translucent rounded Control Center panel.
- Wi-Fi, Bluetooth, network and airplane-mode tiles open Android settings pages. They do not silently toggle protected system radios.
- Brightness slider (requires Modify system settings permission).
- Media volume slider.

## Limitations and next development steps

- Android controls the real status bar and notification shade. A normal non-root app cannot fully replace them.
- This prototype has not been tested on the itel P671L. Device-specific gesture conflicts and background-service behavior must be checked on the phone.
- The current service is a basic overlay service; Android may stop it under background restrictions. A later iteration can add a properly designed foreground-service notification and improve lifecycle handling.
- The panel uses translucent color, not guaranteed real-time background blur; blur support depends on Android version and device implementation.
- The Wi-Fi, Bluetooth and airplane-mode tiles open system settings because Android restricts direct third-party toggling on modern versions.

## Project configuration

- Application ID: `com.example.liquidglassui`
- Namespace: `com.example.liquidglassui`
- Minimum SDK: 26
- Compile SDK: 35
- Target SDK: 34
- Version: 0.1 (prototype source baseline)

## Build status

No APK is included in this source archive. The APK is created only after the GitHub Actions workflow runs successfully.
